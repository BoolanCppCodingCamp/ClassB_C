#pragma once

template<typename Writer, class ... Args>
class CClient: public Writer
{
public:
    CClient(Args ... ctx): Writer(ctx ...) {}
    CClient() = delete;

    void DoProcess() {
        char buf[64] = { 0 };

        memset(buf, 'A', 64);
        Writer::WriteAtBegin(buf, 64);
        memset(buf, 'B', 32);
        Writer::WriteAt(16, buf, 32);
        memset(buf, 'C', 64);
        Writer::WriteAtEnd(buf, 64);
    }
private:
};

