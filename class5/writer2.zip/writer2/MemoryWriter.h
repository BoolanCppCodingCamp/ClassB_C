#pragma once

#include <iostream>

class CMemoryWriter
{
public:
    CMemoryWriter(unsigned char *buf, int bufSize): m_buf(buf), m_bufSize(bufSize) {}

    int WriteAtBegin(void* data, int length) {
        std::cout << "Write " << length << " bytes at file begin" << std::endl;
        return length;
    }
    int WriteAt(int pos, void* data, int length) {
        std::cout << "Write " << length << " bytes at " << pos << std::endl;
        return length;
    }
    int WriteAtEnd(void* data, int length) {
        std::cout << "Write " << length << " bytes at file end" << std::endl;
        return length;
    }

private:
    unsigned char* m_buf;
    int m_bufSize;
};