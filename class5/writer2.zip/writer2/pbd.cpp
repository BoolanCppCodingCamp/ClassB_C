// pbd.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <tuple>
#include "Client.h"
#include "FileWriter.h"
#include "MemoryWriter.h"
#include "TestWriter.h"


int main()
{
    std::string_view filename = "this is a name";
    CClient<CFileWriter, std::string_view> c(filename);
    c.DoProcess();

    unsigned char buf[256] = {};
    CClient<CMemoryWriter, unsigned char*, int> c1(buf, 256);
    c1.DoProcess();

}
