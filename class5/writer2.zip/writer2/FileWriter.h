#pragma once

#include <iostream>
#include <string>


class CFileWriter
{
public:
    CFileWriter(const std::string_view& filename) : m_filename(filename)  {}

    int WriteAtBegin(void* data, int length) {
        std::cout << "Write " << length << " bytes at file begin" << std::endl;
        return length;
    }
    int WriteAt(int pos, void* data, int length) {
        std::cout << "Write " << length << " bytes at " << pos << std::endl;
        return length;
    }
    int WriteAtEnd(void* data, int length) {
        std::cout << "Write " << length << " bytes at file end" << std::endl;
        return length;
    }

private:
    std::string_view m_filename;
};

