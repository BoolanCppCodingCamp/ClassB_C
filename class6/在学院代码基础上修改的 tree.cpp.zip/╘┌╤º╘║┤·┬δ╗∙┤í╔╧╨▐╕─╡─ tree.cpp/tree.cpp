// tree.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <memory>
#include <queue>
#include <optional>

struct Foo
{
    Foo(int a = 0) : m_value(a) { std::cout << "Foo(normal) on: " << a << std::endl; }
    Foo(const Foo& rf) : m_value(rf.m_value) { std::cout << "Foo(copy) on: " << rf.m_value << std::endl; }
    Foo(Foo&& rf) : m_value(rf.m_value) { std::cout << "Foo(mpve) on: " << rf.m_value << std::endl; }
    ~Foo() { std::cout << "~Foo() on: " << m_value << std::endl; }
    
    int m_value;
};

bool operator < (const Foo& lhs, const Foo& rhs)
{
    return lhs.m_value < rhs.m_value;
}
bool operator > (const Foo& lhs, const Foo& rhs)
{
    return lhs.m_value > rhs.m_value;
}


template<typename T>
struct TreeNode final
{
    T data;
    std::weak_ptr<TreeNode<T>> parent;
    std::shared_ptr<TreeNode<T>> left;
    std::shared_ptr<TreeNode<T>> right;
};

template<typename T>
class BinaryTree
{
public:
    void Insert(const T& t)
    {
        if (!root)
        {
            root = std::make_shared<TreeNode<T>>(t);
            return;
        }

        std::shared_ptr<TreeNode<T>> cur = root;
        while (cur)
        {
            if (cur->data < t)
            {
                if (cur->right)
                {
                    cur = cur->right;
                }
                else
                {
                    cur->right = std::make_shared<TreeNode<T>>(t);
                    cur->right->parent = cur;
                    break;
                }
            }
            else if (cur->data > t)
            {
                if (cur->left)
                {
                    cur = cur->left;
                }
                else
                {
                    cur->left = std::make_shared<TreeNode<T>>(t);
                    cur->left->parent = cur;
                    break;
                }
            }
            else
                break;
        }
    }
    void Insert(T&& t)
    {
        //...
    }
    std::optional<T> GetParent(const T& t)
    {
        std::shared_ptr<TreeNode<T>> cur = root;
        while (cur)
        {
            if (cur->data < t)
                cur = cur->right;
            else if (cur->data > t)
                cur = cur->left;
            else
            {
                auto pptr = cur->parent.lock();
                return pptr->data;
            }
        }

        return std::nullopt;
    }

    virtual ~BinaryTree()
    {
        std::queue<std::shared_ptr<TreeNode<T>>> nq;
        nq.emplace(std::move(root));
        while (!nq.empty())
        {
            auto& front = nq.front();
            if (front->left)
                nq.emplace(std::move(front->left));
            if (front->right)
                nq.emplace(std::move(front->right));
            
            nq.pop();
        }
    }
private:
    std::shared_ptr<TreeNode<T>> root;
};

int main()
{
    BinaryTree<Foo> fTree;
    for (auto& v : { 1,3,5,9,2,0,8,12,55,33 })
    {
        fTree.Insert(v);
    }
    
    {
        auto r = fTree.GetParent(12);
        if (r)
        {
            std::cout << "12's parent is: " << r.value().m_value << std::endl;
        }
    }
    std::cout << "----------------------" << std::endl;
}

