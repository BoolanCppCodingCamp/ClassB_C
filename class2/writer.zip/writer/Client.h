#pragma once

#include "Writer.h"

class CClient final
{
public:
    CClient(CWriter* writer) : m_writer(writer) {}
    CClient() = delete;
    ~CClient() {}

    void DoProcess() {
        char buf[64] = { 0 };

        memset(buf, 'A', 64);
        m_writer->WriteAtBegin(buf, 64);
        memset(buf, 'B', 32);
        m_writer->WriteAt(16, buf, 32);
        memset(buf, 'C', 64);
        m_writer->WriteAtEnd(buf, 64);
    }
private:
    CWriter *m_writer;
};

