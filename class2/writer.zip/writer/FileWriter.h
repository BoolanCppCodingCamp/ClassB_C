#pragma once

#include <iostream>
#include <string>
#include "Writer.h"


class CFileWriter : public CWriter
{
public:
    CFileWriter(const std::string& filename) {}
    virtual ~CFileWriter() {}

    virtual int WriteAtBegin(void* data, int length) {
        std::cout << "Write " << length << " bytes at file begin" << std::endl;
        return length;
    }
    virtual int WriteAt(int pos, void* data, int length) {
        std::cout << "Write " << length << " bytes at " << pos << std::endl;
        return length;
    }
    virtual int WriteAtEnd(void* data, int length) {
        std::cout << "Write " << length << " bytes at file end" << std::endl;
        return length;
    }

private:

};

