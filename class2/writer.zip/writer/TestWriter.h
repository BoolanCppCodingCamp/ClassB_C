#pragma once

#include <vector>
#include "Writer.h"

class CTestWriter : public CWriter
{
public:
    CTestWriter() {}
    virtual ~CTestWriter() {}

    virtual int WriteAtBegin(void* data, int length) {
        m_logs.push_back({0, length});
        return length;
    }
    virtual int WriteAt(int pos, void* data, int length) {
        m_logs.push_back({ pos, length });
        return length;
    }
    virtual int WriteAtEnd(void* data, int length) {
        m_logs.push_back({ 0xFFFFFFFF, length });
        return length;
    }

private:
    std::vector<std::pair<int, int>> m_logs;
};