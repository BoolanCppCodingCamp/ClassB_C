#pragma once

class CWriter
{
public:
    virtual int WriteAtBegin(void* data, int length) = 0;
    virtual int WriteAt(int pos, void* data, int length) = 0;
    virtual int WriteAtEnd(void* data, int length) = 0;
};