#pragma once

#include <iostream>
#include "Writer.h"

class CMemoryWriter : public CWriter
{
public:
    CMemoryWriter() {}
    virtual ~CMemoryWriter() {}

    virtual int WriteAtBegin(void* data, int length) {
        std::cout << "Write " << length << " bytes at file begin" << std::endl;
        return length;
    }
    virtual int WriteAt(int pos, void* data, int length) {
        std::cout << "Write " << length << " bytes at " << pos << std::endl;
        return length;
    }
    virtual int WriteAtEnd(void* data, int length) {
        std::cout << "Write " << length << " bytes at file end" << std::endl;
        return length;
    }

private:

};