// stdv.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <format>
#include <vector>
#include "Timer.h"

Timer s_timer;

std::vector<std::string> GetStrings()
{
    std::vector<std::string> vs;
    vs.reserve(10000);

    for (int i = 0; i < 10000; i++)
    {
        vs.push_back(std::format("Test string generator at ....... {}", i));
    }

    s_timer.Start();
    return vs;
}
#if 0
int main()
{
    std::vector<std::string> vs;
    vs.reserve(10000);

    for (int i = 0; i < 10000; i++)
    {
        vs.push_back(std::format("Test string generator at ....... {}", i));
    }

    std::vector<std::string> another;
    Timer timer;
    timer.Start();
    //another = vs;
    another = std::move(vs);
    unsigned long long ms = timer.GetNS();
    std::cout << ms << ", " << another.size() << std::endl;
}
#endif
#if 1
int main()
{
    std::vector<std::string> vs = GetStrings();
    //vs.push_back("dfgsfhgdf");

    unsigned long long ms = s_timer.GetNS();
    std::cout << ms << ", " << vs.size() << std::endl;

}
#endif



