// class4.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <mutex>
#include <thread>
#include <functional>
#include <cstdio>
#include "WaitCursor.h"
#include "WinSockInit.h"
#include "ScopeGuard.h"
#include "FooTest.h"


void SomeFunc()
{
    FILE* fp = fopen("filename", "wb");

    ScopeGuard<std::function<void()>> guard([&fp]() { fclose(fp); });

    //using

}

int main()
{
    int i = 0;


    {
        CWaitCursor wait;
        //Do something....
    }
}
