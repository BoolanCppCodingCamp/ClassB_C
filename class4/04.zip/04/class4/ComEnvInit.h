#pragma once

#include "Objbase.h"

class ComEnvInit final
{
public:
    ComEnvInit(DWORD apartment)
    {
        HRESULT hr = ::CoInitializeEx(NULL, apartment);
        m_status = (hr == S_OK);
    }
    ~ComEnvInit()
    {
        ::CoUninitialize();
    }
    operator bool() { return m_status; }
private:
    bool m_status;
};

#if 0
int main()
{
    ComEnvInit comInit(COINIT_APARTMENTTHREADED);
    if (!comInit)
    {
        //������
    }
}
#endif