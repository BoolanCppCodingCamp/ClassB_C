#pragma once


template<typename Func>
class ScopeGuard final
{
public:
    ScopeGuard(Func func) : m_Func(func) {}
    ~ScopeGuard() { m_Func(); }
private:
    Func m_Func;
};

