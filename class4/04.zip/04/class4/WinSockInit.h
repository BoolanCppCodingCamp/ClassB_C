#pragma once

#include <winsock2.h>

class WinSockInit final
{
public:
    WinSockInit(int majorVer = 2, int minorVer = 2)
    {
        WSADATA wsaData = { 0 };
        int err = ::WSAStartup(MAKEWORD(minorVer, majorVer), &wsaData);
        m_status = (err == 0);
    }
    ~WinSockInit()
    {
        ::WSACleanup();
    }
    operator bool() { return m_status; }
private:
    bool m_status;
};

#if 0
int main()
{
    WinSockInit sockinit;
    if (!sockinit)
    {
        //������
    }
}
#endif