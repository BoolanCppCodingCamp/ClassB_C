#pragma once

class CWaitCursor
{
	// Construction/Destruction
public:
	CWaitCursor()
	{
		//AfxGetApp()->BeginWaitCursor()
	}
	~CWaitCursor()
	{
		//AfxGetApp()->EndWaitCursor();
	}

	// Operations
public:
	void Restore()
	{
		//AfxGetApp()->RestoreWaitCursor();
	}
};
