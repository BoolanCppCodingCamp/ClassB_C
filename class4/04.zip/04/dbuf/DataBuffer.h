#pragma once

#include <utility>
#include <string>
#include <vector>

#define SUPPORT_MOVE   1
#define SUPPORT_VECTOR   0

class CDataBuffer
{
public:
    CDataBuffer();
    CDataBuffer(void *data, int dataLength);
    CDataBuffer(const CDataBuffer& db);
#if SUPPORT_MOVE
    CDataBuffer(CDataBuffer&& db);
#endif
    virtual ~CDataBuffer();
    
    CDataBuffer& operator = (const CDataBuffer& db);
#if SUPPORT_MOVE
    CDataBuffer& operator = (CDataBuffer&& db);
#endif

    unsigned int GetDataLength() const { return m_DataLength; }
#if SUPPORT_VECTOR
    void InitVector();
#endif
protected:
    void Swap(CDataBuffer& db) noexcept;
    unsigned char* CopyBuffer(void* data, int dataLength);

protected:
    std::string m_dataName;
    unsigned char* m_dataBuf;
    unsigned int m_DataLength;
#if SUPPORT_VECTOR
    std::vector<int> m_ints;
#endif
};

