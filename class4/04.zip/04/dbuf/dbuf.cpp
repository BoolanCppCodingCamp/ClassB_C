// dbuf.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "DataBuffer.h"
#include "Timer.h"

const int s_buf_size = 4096;
char data[s_buf_size];

CDataBuffer GetDataBuf()
{
    CDataBuffer buf(data, s_buf_size);
#if SUPPORT_VECTOR
    buf.InitVector();
#endif
    return buf;
}

int main()
{
    memset(data, 'A', s_buf_size);

    Timer timer;
    unsigned long long total = 0;
    for (int run = 0; run < 100; run++)
    {
        timer.Start();
        for (int i = 0; i < 10000; i++)
        {
            CDataBuffer buf;
            buf = GetDataBuf();
            unsigned int length = buf.GetDataLength();
        }
    
        total += timer.GetMS();
    }
    std::cout << "timer duration: " << total / 100.0 << std::endl;
}
