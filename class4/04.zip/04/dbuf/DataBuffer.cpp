#include <iostream>
#include <cassert>
#include "DataBuffer.h"

inline static unsigned int RoundSize(unsigned int size, unsigned int round)
{
    if (round == 0)
        round = 32;

    return (size / round + 1) * round;
}

CDataBuffer::CDataBuffer() : m_dataName("defaule name")
{
    m_dataBuf = nullptr;
    m_DataLength = 0;
}

CDataBuffer::CDataBuffer(void* data, int dataLength) : m_dataName("defaule name")
{
    m_dataBuf = CopyBuffer(data, dataLength);
    m_DataLength = dataLength;
}

CDataBuffer::CDataBuffer(const CDataBuffer& db) : m_dataName(db.m_dataName)
{ 
    m_dataBuf = CopyBuffer(db.m_dataBuf, db.m_DataLength);
    m_DataLength = db.m_DataLength;
#if SUPPORT_VECTOR
    m_ints = db.m_ints;
#endif
}

#if SUPPORT_MOVE
CDataBuffer::CDataBuffer(CDataBuffer&& db) 
{ 
    std::swap(m_dataBuf, db.m_dataBuf);
    std::swap(m_dataName, db.m_dataName);
    std::swap(m_DataLength, db.m_DataLength);
#if SUPPORT_VECTOR
    m_ints = std::move(db.m_ints);
#endif
}
#endif

CDataBuffer::~CDataBuffer() 
{ 
    if (m_dataBuf != nullptr)
    {
        delete[] m_dataBuf;
    }

    m_dataBuf = nullptr;
    m_DataLength = 0;
    //m_dataName.clear(); 
}

CDataBuffer& CDataBuffer::operator = (const CDataBuffer& db)
{
    //std::cout << "Copyed!" << std::endl;
    if (this != &db)
    {
        CDataBuffer tmp(db); // �������죬tmp �����쳣��Ӱ�� this
        Swap(tmp); //�쳣��ȫ�� Swap
    }

    return *this;
}

#if SUPPORT_MOVE
CDataBuffer& CDataBuffer::operator = (CDataBuffer&& db) 
{
    //std::cout << "Moved!" << std::endl;
    if (this != &db)
    {
        CDataBuffer tmp(std::forward<CDataBuffer>(db));  //��ֵ������ʱ����
        Swap(tmp); //�쳣��ȫ�� Swap
    }

    return *this;
}
#endif

#if SUPPORT_VECTOR
void CDataBuffer::InitVector()
{
    m_ints.reserve(10000);
    for (int i = 0; i < 10000; i++)
    {
        m_ints[i] = i;
    }
}
#endif

void CDataBuffer::Swap(CDataBuffer& db) noexcept
{
    std::swap(m_dataBuf, db.m_dataBuf);
    std::swap(m_dataName, db.m_dataName);
    std::swap(m_DataLength, db.m_DataLength);
#if SUPPORT_VECTOR
    std::swap(m_ints, db.m_ints);
#endif
}

unsigned char* CDataBuffer::CopyBuffer(void* data, int dataLength)
{
    unsigned char* tmp = nullptr;
    try
    {
        tmp = new unsigned char[RoundSize(dataLength, 32)];
        memcpy(tmp, data, dataLength);
        m_DataLength = dataLength;
    }
    catch (...)
    {
        if (tmp != nullptr)
        {
            delete[] tmp;
            tmp = nullptr;
        }
        m_DataLength = 0;
        throw;
    }

    return tmp;
}
