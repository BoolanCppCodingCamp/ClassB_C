// move.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "FooTest.h"


void PrintValue(const FooTest& rf)
{
    std::cout << "const lvalue rf = " << rf.GetValue() << std::endl;
}

void PrintValue(FooTest& rf)
{
    std::cout << "lvalue rf = " << rf.GetValue() << std::endl;
}

void PrintValue(FooTest&& rrf)
{
    std::cout << "rvalue rrf = " << rrf.GetValue() << std::endl;
}

FooTest GetFoo()
{
    FooTest ft(5);
    return ft;
}
/*
void Process(FooTest&& f)
{
    std::cout << "f is rreference: " << std::boolalpha
              << std::is_rvalue_reference_v<decltype(f)> << std::endl;

    PrintValue(f); 
}
*/

void Process(FooTest&& t)
{
    PrintValue(t);
}

int main()
{
    //PrintValue(GetFoo());

    Process(GetFoo()); //FooTest
}



